package by.it.services;

import by.it.model.User;

public interface UserService {

	User findById(int id);
	
	User findByUserName(String userName);
	
}



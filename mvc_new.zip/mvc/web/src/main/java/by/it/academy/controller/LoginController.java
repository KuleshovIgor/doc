package by.it.academy.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Authentication controller
 */
@Controller
public class LoginController {

    /**
     * Checks the user's input in the form
     * @param model
     * @param param
     * @return login page if user not authorized
     */
    @RequestMapping(value = {"/login"})
    public String login(Model model, @RequestParam(value = "login", required = false) String param) {
        if ("e".equals(param)) {
            model.addAttribute("error", "Incorrect username or password");
            return "login";
        } else if ("new".equals(param)) {
            return "login";
        }
        return "login";
    }

}

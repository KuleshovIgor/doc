package by.it.academy.controller;

import by.it.academy.pojos.Product;
import by.it.academy.services.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Created by yslabko on 02/24/2016.
 */

@RestController
@RequestMapping("/products")
public class ProductController {
    @Autowired
    private IProductService productService;
    @RequestMapping(value = "", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<List<Product>> getProducts() {
        List<Product> products = productService.getAllProducts();
        if(products.isEmpty()){ return new ResponseEntity<>(HttpStatus.NO_CONTENT); }
        return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
    }
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<Product> getProduct(@PathVariable("id") Long id) {
        Product product = productService.get(id);
        if (product == null) { return new ResponseEntity<>(HttpStatus.NOT_FOUND);}
        return new ResponseEntity<>(product, HttpStatus.OK);
    }
    @RequestMapping(value = "", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public void addProduct(@RequestBody Product product) {
        productService.add(product);
    }
    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public ResponseEntity<Product> updateProducts(@PathVariable("id") Integer id, @RequestBody Product newProduct) {
        Product product = productService.get(id);
        if (product == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        product.setModel(newProduct.getModel());
        product.setName(newProduct.getName());
        product.setPrice(newProduct.getPrice());
        newProduct = productService.update(product);
        return new ResponseEntity(product, HttpStatus.OK);
    }
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.OK)
    public void deleteProduct(@PathVariable("id") Integer id) {
        productService.delete(id);
    }

    @RequestMapping(value = "/page", method = RequestMethod.GET)
    public String getProductsPage(ModelMap map) {
        map.addAttribute("product", new Product());
        map.addAttribute("products", productService.getAllProducts());
        return "products/main";
    }

}

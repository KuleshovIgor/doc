package by.it.academy.dao;

import by.it.academy.pojos.Product;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.io.Serializable;
import java.util.List;

/**
 * Created by yslabko on 02/24/2016.
 */
@Repository
public class ProductDao extends BaseDao<Product> implements IProductDao {

    @Autowired
    public ProductDao(SessionFactory sessionFactory){
        super(sessionFactory);
    }

    @Override
    public List<Product> getProducts() {
        String hql = "from Product";
        Query query = getSession().createQuery(hql);

        return query.list();
    }

    @Override
    public void delete(Serializable id) {
        getSession().createQuery("delete from Product p where p.id=:id")
            .setParameter("id", id)
            .executeUpdate();
    }
}
package by.it.academy.dao;

import by.it.academy.pojos.Product;

import java.io.Serializable;
import java.util.List;

/**
 * Created by yslabko on 02/24/2016.
 */
public interface IProductDao extends Dao<Product> {
    List<Product> getProducts();
    void delete(Serializable id);
}

package by.it.academy.services;

import by.it.academy.pojos.Product;

import java.io.Serializable;
import java.util.List;

/**
 * Created by yslabko on 02/24/2016.
 */
public interface IProductService extends IService <Product> {
    List<Product> getAllProducts();
    void delete(Serializable id);
}

package by.it.academy.services;

import by.it.academy.dao.IProductDao;
import by.it.academy.pojos.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.List;

/**
 * Created by yslabko on 02/24/2016.
 */
@Service
@Transactional
public class ProductService extends BaseService<Product> implements IProductService {

    @Autowired
    private IProductDao productDao;

    @Override
    public List<Product> getAllProducts() {
        return productDao.getProducts();
    }

    @Override
    public void delete(Serializable id) {
        productDao.delete(id);
    }
}
